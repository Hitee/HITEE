$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("definitions/validate.feature");
formatter.feature({
  "line": 1,
  "name": "",
  "description": "",
  "id": "",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Test name",
  "description": "",
  "id": ";test-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "check user name",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "enter empty value in user name text box",
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "#click to be added"
    }
  ],
  "line": 7,
  "name": "print error message for name field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_user_name()"
});
formatter.result({
  "duration": 3455289946,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_user_name_text_box()"
});
formatter.result({
  "duration": 3221043848,
  "error_message": "java.lang.NullPointerException\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke(Unknown Source)\r\n\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)\r\n\tat java.lang.reflect.Method.invoke(Unknown Source)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:51)\r\n\tat com.sun.proxy.$Proxy15.sendKeys(Unknown Source)\r\n\tat definitions.FormPageFactory.setUname(FormPageFactory.java:46)\r\n\tat definitions.StepDef.enter_empty_value_in_user_name_text_box(StepDef.java:34)\r\n\tat ✽.When enter empty value in user name text box(definitions/validate.feature:5)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_name_field()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenario({
  "line": 9,
  "name": "Test password",
  "description": "",
  "id": ";test-password",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 10,
  "name": "check user password",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "enter empty value in password text box",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "print error message for password field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_user_password()"
});
formatter.result({
  "duration": 3723151507,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_password_text_box()"
});
formatter.result({
  "duration": 190999201,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_password_field()"
});
formatter.result({
  "duration": 23911002,
  "error_message": "org.openqa.selenium.NoAlertPresentException: no such alert\n  (Session info: chrome\u003d70.0.3538.102)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 6.1.7601 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 21 milliseconds\nBuild info: version: \u00272.48.2\u0027, revision: \u002741bccdd\u0027, time: \u00272015-10-09 19:59:12\u0027\nSystem info: host: \u0027CHNSIPDT0T504\u0027, ip: \u002710.219.35.26\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027x86\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_45\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities [{mobileEmulationEnabled\u003dfalse, hasTouchScreen\u003dfalse, platform\u003dXP, acceptSslCerts\u003dfalse, goog:chromeOptions\u003d{debuggerAddress\u003dlocalhost:53879}, acceptInsecureCerts\u003dfalse, webStorageEnabled\u003dtrue, browserName\u003dchrome, takesScreenshot\u003dtrue, javascriptEnabled\u003dtrue, setWindowRect\u003dtrue, unexpectedAlertBehaviour\u003d, applicationCacheEnabled\u003dfalse, rotatable\u003dfalse, networkConnectionEnabled\u003dfalse, chrome\u003d{chromedriverVersion\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a), userDataDir\u003dC:\\Users\\hisachde\\AppData\\Local\\Temp\\scoped_dir12780_27668}, takesHeapSnapshot\u003dtrue, pageLoadStrategy\u003dnormal, databaseEnabled\u003dfalse, handlesAlerts\u003dtrue, version\u003d70.0.3538.102, browserConnectionEnabled\u003dfalse, nativeEvents\u003dtrue, locationContextEnabled\u003dtrue, cssSelectorsEnabled\u003dtrue}]\nSession ID: 83f357e50609bf3b9fb23a01f71975bc\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:206)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:158)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:647)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:670)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:1007)\r\n\tat definitions.StepDef.print_error_message_for_password_field(StepDef.java:72)\r\n\tat ✽.Then print error message for password field(definitions/validate.feature:12)\r\n",
  "status": "failed"
});
});