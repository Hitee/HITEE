package definitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	private FormPageFactory fact;
	private WebDriver driver;


	@Given("^check user name$")
	public void check_user_name() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new FormPageFactory(driver);
		driver.get("file:///C:/Users/hisachde/Desktop/Basicform.html");

		
	}

	@When("^enter empty value in user name text box$")
	public void enter_empty_value_in_user_name_text_box() throws Throwable {
		fact.setUname("");
		fact.setButton();

		
			}

	@Then("^print error message for name field$")
	public void print_error_message_for_name_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@Given("^check user password$")
	public void check_user_password() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new FormPageFactory(driver);
		driver.get("file://ndafile/Study%20Materials/Common/ELTP/2017/JEE%20Propel/Demo1.html");

		
			}

	@When("^enter empty value in password text box$")
	public void enter_empty_value_in_password_text_box() throws Throwable {
		fact.setUname("arvind");
		fact.setPassword("");
		fact.setButton();
	
	}

	@Then("^print error message for password field$")
	public void print_error_message_for_password_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
		}

}
