package com.cg.jpastart.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
EntityManagerFactory factoy = Persistence.createEntityManagerFactory("JPA-PU");
EntityManager em = factoy.createEntityManager();
Student student = em.find(Student.class, 1);
System.out.println(student.getStudentId() + ", " + student.getName());
Address address1 = student.getAddress();
System.out.println(address1.getCity());
System.out.println("-----------------");
Address address = em.find(Address.class, 1);
System.out.println(address.getCity() + ", " + address.getState());
Student s = address.getStudent();
System.out.println(s.getStudentId() + ", " + s.getName());
	}

}
