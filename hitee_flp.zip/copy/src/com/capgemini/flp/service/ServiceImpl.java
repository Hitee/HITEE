package com.capgemini.flp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.flp.bean.User;
import com.capgemini.flp.dao.IDao;

@Service("userService")
//@Transactional(propagation = Propagation.SUPPORTS , rollbackFor = Exception.class)
public class ServiceImpl implements IService{

	@Autowired
	IDao dao;
	
	@Override
	public String create(User user) {
		return dao.create(user);
		
	}

	/*public User find(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public String updateCustomer(User c) {
		// TODO Auto-generated method stub
		return null;
	}
*/
	
	
}
