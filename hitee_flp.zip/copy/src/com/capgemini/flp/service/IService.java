package com.capgemini.flp.service;

import com.capgemini.flp.bean.User;




public interface IService {

	public String create(User user);

}
