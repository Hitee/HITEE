package com.capgemini.flp.dao;

import com.capgemini.flp.bean.User;

public interface IDao {

	public String create(User user);
}
