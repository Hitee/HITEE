package com.capgemini.flp.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.flp.bean.User;

@Repository
@Transactional
public class DaoImpl implements IDao{
	
	@PersistenceContext
	@Autowired
	EntityManager entityManager;
	
	@Override
	public String create(User user) {
	entityManager.persist(user);
	return "success";
	}

}
