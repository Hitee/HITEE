package com.capg.cms.ui;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

import com.capg.cms.beans.Customer;
import com.capg.cms.expection.CustomerNotFound;
import com.capg.cms.service.CustomerServiceImp;


public class Client {
	//static Customer c11 = new Customer();
	public static void main(String[] args) throws IOException, CustomerNotFound {
		// TODO Auto-generated method stub
		Customer c1 = new Customer();
	
		CustomerServiceImp service = new CustomerServiceImp();
		
		while(true)
		{
			
			//System.out.println("WORKING");
			try
			{
				System.out.println("--------");
		System.out.println("Welcome to Banking");
		System.out.println("1. Create account");
		System.out.println("2. Show balance");
		System.out.println("3. Deposit");
		System.out.println("4. Withdraw");
		System.out.println("5. Fund transfer");
		System.out.println("6. Print transaction");
		System.out.println("7. Exit");
		 

		Scanner sc = new Scanner(System.in);
		//System.out.println(sc);
		int Choice = sc.nextInt();

		switch (Choice) 
		{
		case 1: 
			Customer bean  = new Customer();
			
			/*BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
			StringBuffer name = new StringBuffer();*/

			Scanner sc1 = new Scanner(System.in);
			Scanner sc2 = new Scanner(System.in);
			String name;
			do
			{
			System.out.println("Enter name");
			name = sc1.nextLine();
			//System.out.println(name);
			}
			while(!service.validateName(name));
			bean.setName(name);
			
			String email;
			do
			{
			System.out.println("Enter email id");
			email = sc.next();
			}while(!service.isValidEmailAddress(email));
			bean.setEmailId(email);
			
			String addr; 
			do
			{
			System.out.println("Enter address");
			addr = sc1.nextLine();
			bean.setAddr(addr);
			}
			while(!service.validateAddr(addr));
			
			String id;
			do
			{
			System.out.println("Enter id proof number(5 digit id)");
			id = sc.next();
			}
			while(!service.validateId(id));
			bean.setId(id);
						
			String mobile;
			do
			{
			System.out.println("Enter mobile number");
			mobile = sc.next();
			}
			while(!service.validateNumber(mobile) );
			bean.setMobileNo(mobile);
			
			int age;
			do
			{
			System.out.println("Enter age");
			age = sc.nextInt();
			}
			while(!service.validateAge(age));
			bean.setAge(age);
			
			Random rnd = new Random();
			int accountNo = 100000 + rnd.nextInt(900000);
			System.out.println(accountNo);
			bean.setAccountNo(accountNo);
			
			Random rnd2 = new Random();
			int pin = 1000 + rnd.nextInt(9000);
			System.out.println(pin);
			bean.setPin(pin);
			
			double balance;
			do
			{
			System.out.println("Enter initial balance");
			balance = sc.nextInt();
			}
			while(!service.validateBalance(balance));
			bean.setBalance(balance);
			
			System.out.println(bean);
			//handing objects to bean object after taking input from user
			long a = bean.getAccountNo();
			boolean isAdded = service.addCustomer(a, bean);
			service.printTransactions(bean);
			break;
		
			
		
		case 2:
			Customer c = new Customer();
			try
			{
				
									try
									{
									System.out.println("Enter account number and pin to show balance");
									System.out.println("Enter account number");
									long accountNo2 = sc.nextLong();
									System.out.println("Enter pin");
									int pin2 = sc.nextInt();
									c = service.displayCustomer(accountNo2, pin2);
									if(c!=null)
										System.out.println("Rs. " + c.getBalance() + " is the balance of " + c.getAccountNo());
										
									//System.out.println(c);
									//throw new  InputMismatchException();
									}
									catch(InputMismatchException e)
									{
										System.out.println("Input Mismatch Exception");
									}
									finally
									{
										System.out.println("\n");
									}
			
			if(c==null)
			{
				throw new CustomerNotFound();
			}
			
			}
			catch(CustomerNotFound e )
			{
				System.out.println("Exception caught");
				//System.out.println(e);
			}
			finally
			{
				System.out.println("\n");
			}
			break;
		
		
			
			
		case 3:
			Customer ac = new Customer();
			try
			{
			
						
									try
									{
									
											System.out.println("Enter account number and amount to be deposited");
											
											System.out.println("Enter account no");
											long accountNo3 = sc.nextLong();
											
											
											System.out.println("Enter amount to be deposited");
											double depositAmount = sc.nextDouble();
											
										
											ac = service.deposit(accountNo3, depositAmount);
											if(ac!=null)
												{
												System.out.println("Balance for account number "+ ac.getAccountNo() + " is now: " + ac.getBalance()) ;
												service.printTransactions(ac);
												}
									}catch(InputMismatchException e)
									{
										
										System.out.println("Input Mismatch Exception");
									}
									finally
									{
										System.out.println("\n");
									}
			//System.out.println();
			
			if(ac==null)
				throw new CustomerNotFound();
			
		}
		catch(CustomerNotFound e)
		{
			System.out.println("Exception caught");
			//e.getMessage();
		}
			finally
			{
				System.out.println("\n ");
			}
			break;
			
			
		case 4:
			Customer c8 = new Customer();
			try
			{
			
				
						try
						{
								System.out.println("Enter account number and pin to proceed");
								
								System.out.println("Enter account number");
								long accountNo4 = sc.nextLong();
					
								System.out.println("enter pin");
								int pin4 = sc.nextInt();
								
								System.out.println("Enter amount to be withdrawn");
								double withdrawAmount = sc.nextDouble();
								
								
								c8 = service.withdraw(accountNo4 , pin4 , withdrawAmount);
								
								if(c8!=null)
								{
								System.out.println("Balance for account number "+ c8.getAccountNo() + " is now: " + c8.getBalance());
								
								service.printTransactions(c8);
								}
						}catch(InputMismatchException e)
						{
							System.out.println("Input Mismatch Exception");
						}
						finally
						{
							System.out.println("\n");
						}
									
									
									
				if(c8==null)
			 throw new CustomerNotFound();
			}
			catch(CustomerNotFound e)
			{
				System.out.println("Exception caught");
				//e.getMessage();
			}
				finally
				{
					System.out.println("\n ");
				}
			
			break;

			
		case 5:
			Customer to = new Customer();
			Customer from = new Customer();
			try
			{
			
						try
						{
							System.out.println("Enter your account number");
									long accountNo5 = sc.nextLong();
									
									System.out.println("Enter your pin");
									int pin5 = sc.nextInt();
									
									System.out.println("Enter account number to which you want to transfer amount");
									long accountNoTransfer = sc.nextLong();
									
									System.out.println("Enter amount");
									double amountTransfer = sc.nextDouble();
									
									
									to = service.fundTransfer(accountNo5 , pin5 , accountNoTransfer , amountTransfer);
									
									from = new Customer();
									//service.printTransactions(to);
									////// this is only for FROM ACCOUNT //////
									if (to!=null)
									 {
										
										System.out.println("FROM");
										from = service.displayCustomer(accountNo5, pin5);
										if(from!=null)
										{
											service.printTransactions(from);
											service.printTransactions(to);
											System.out.println("Amount transfered to : " + to.getAccountNo() + " balance = " + to.getBalance());
											
										}
									
										
										//to = null ;
									}
			}catch(InputMismatchException e)
			{
				System.out.println("Input Mismatch Exception");
			}
			finally
			{
				System.out.println("\n");
			}
			
			if(to == null || from == null)
			{
				throw new CustomerNotFound(); 
			}
			}
			catch(CustomerNotFound e)
			{
				System.out.println("Exception caught");
				//e.getMessage();
			}
				finally
				{
					System.out.println("\n ");
				}
			
			break;
			
		case 6:
			//Customer c3 = new Customer();
			boolean c3 = false;
			try
			{
			
								try
								{
								System.out.println("Enter account number and pin to print transactions");
								
								System.out.println("Enter your account number");
								long accountNo6 = sc.nextLong();
								
								System.out.println("Enter your pin");
								int pin6 = sc.nextInt();
								
								c3 = service.printTrns(accountNo6);
								}
								catch(InputMismatchException e)
								{
									System.out.println("Input Mismatch Exception");
								}
								finally
								{
									System.out.println("\n");
								}
				if(c3 == false)
				{
					throw new CustomerNotFound(); }
			}
			
			catch(CustomerNotFound e)
			{
				System.out.println("Exception caught");
				//e.getMessage();
			}
				finally
				{
					System.out.println("\n ");
				}
			
			
			
			break;
		case 7:
			System.exit(0);
			
			break;
		default:
			break;
		}

	
			//throw new InputMismatchException();
		}
		catch(InputMismatchException e )
		{
			System.out.println("Exception caught");
			System.out.println("Input Mismatch Exception");
		}
		finally
		{
			System.out.println("\n");
		}
	}
		

}
}