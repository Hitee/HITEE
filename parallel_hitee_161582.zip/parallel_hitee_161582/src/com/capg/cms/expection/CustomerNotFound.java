package com.capg.cms.expection;

public class CustomerNotFound extends Exception
{

	String e;
	public CustomerNotFound(/*String e*/) {
		System.out.println("CUSTOMER NOT FOUND");
		//System.out.println(e);
		//super(e);
	}
	
	
	
	
}
