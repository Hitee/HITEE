package com.capg.cms.dao;
import java.util.HashMap;
import java.util.Map;

import com.capg.cms.beans.Customer;
import com.capg.cms.expection.CustomerNotFound;
public class CustomerDAOImp implements ICustomerDAO {
StringBuffer sb = new StringBuffer();
	//for database use collections
	
	Map<Long, Customer> custList = new HashMap<Long, Customer>();
	Map<Long, StringBuffer> transaction = new HashMap<Long, StringBuffer>();
	
	@Override
	public boolean addCustomer(long accNo, Customer c) 
	{
		// TODO Auto-generated method stub
		
		boolean isAdded = false;
	
		// add - predefined method of collections, returns boolean value
		custList.put(accNo,c);
		//System.out.println("this is custlist" + custList);
		
		return isAdded;
	
	
	}

	//@Override
	public Customer displayCustomer(long accountNo , int pin) 
	{
		// TODO Auto-generated method stub
		//System.out.println("gertr");
		Customer cust = null;
		for (Customer custList1 : custList.values() ) 
		{
		if(custList1.getAccountNo() == accountNo && custList1.getPin() == pin)
		{
			cust = custList1;
			//System.out.println("inside ");
			// System.out.println("Value = " + custList1.getBalance());
		}
		//else System.out.println("no customer !");
		   
		}
		
		return cust;
	}
	
	
	
	public Customer deposit(long accountNo , double depositAmount) 
	{
		// TODO Auto-generated method stub
		
		Customer cust = null;
		
		for (Customer custList1 : custList.values()) 
		{
		if(custList1.getAccountNo() == accountNo)
		{
			 //System.out.println("Value = " + custList.getBalance());
			//transaction.put(custList1.getAccountNo() , sb.append("deposited amount " + depositAmount));
		}
		   
		}
		
	
		//
		for(Customer custList : custList.values())
		{
			if(custList.getAccountNo() == accountNo)
				
		
			{
				
				double amt = custList.getBalance();
				
				
				amt = amt + depositAmount;
				custList.setBalance(amt);
				
				//System.out.println(".......");
				//System.out.println(transaction);
				
				cust = custList;
			}
		}
		
		
		return cust;
	}
	
	
	
	public Customer withdraw(long accountNo , int pin , double withdrawAmount) 
	{
		// TODO Auto-generated method stub
		
		Customer cust = null;
		
		for (Customer custList : custList.values()) 
		{
		if(custList.getAccountNo() == accountNo)
			{
				double amt = custList.getBalance();
				if(withdrawAmount < amt)
				{
					amt = amt - withdrawAmount;
					
					custList.setBalance(amt);
					cust = custList;
					
					
					
				}
				
			}
		}
		
		return cust;
		
	}
	
	
	public Customer fundTransfer(long accountNo , int pin, long accountNoTransfer , double amountTransfer)
	{
		Customer cust = null;
		//final Customer c ;
		for (Customer custList1 : custList.values()) 
		{
			
		if(custList1.getAccountNo() == accountNo && custList1.getPin() == pin /*&& tr.getAccountNo()== accountNoTransfer*/)
		
			{
				double amt = custList1.getBalance();
				if(amountTransfer < amt)
				{
					double from = custList1.getBalance();
					from = from - amountTransfer;
					
					for (Customer custList2 : custList.values()) 
					{
					if(custList.containsKey(accountNoTransfer)/* && custList.containsKey(accountNo)*/)
					{
						final Customer c  = custList2;
						
						//c = custList2;
						cust = c;
						double to = custList2.getBalance();
						to = to + amountTransfer;
						custList2.setBalance(to);
						custList1.setBalance(from);
						System.out.println("PRINTING custlist 1 "+ custList1 + "custlist2" + custList2);
						
						//System.out.println(custList2.getBalance() + "vdf");
						
					}
					else 
					{
						System.out.println("sssssssss");
					}
				}
					
				
				
			}
		}
		}
		
		return cust;
	}
	
	public Customer printTransactions(Customer ac)
	{
		Customer cust = null;
		long a = ac.getAccountNo();
		StringBuffer s = new StringBuffer();
		s = ac.getSb();
		s.append("Balance: ");
		s.append(ac.getBalance());
		s.append("\n");
		ac.setSb(s);
		transaction.put(a, s);
		return cust;
	}

	@Override
	public boolean printTrns(long ac) {
		// TODO Auto-generated method stub
		Object value = null;
		if (transaction.containsKey(ac)) {
			  value = transaction.get(ac);
			 System.out.println("Account number : " + ac +"\n"+ value + "\n");
			 return true;
			 }
		/*Customer c = new Customer();
		c = (Customer)value; 
		return c;*/
		return false;
	}
	
	
	
	

}
