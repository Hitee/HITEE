package stepDefinition;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class FormPageFactory {

	@FindBy(how = How.NAME, using = "userName") 
	@CacheLookup
	WebElement userName;
	
	@FindBy(how = How.NAME, using = "city") 
	@CacheLookup
	WebElement city;
	
	@FindBy(how = How.NAME, using = "password") 
	@CacheLookup
	WebElement password;
	
	@FindBy(how = How.NAME, using = "mobile") 
	@CacheLookup
	WebElement mobile;
	
	@FindBy(how = How.XPATH, using = "/html/body/center/form/input[12]") 
	@CacheLookup
	WebElement email;
	
	@FindBy(how = How.NAME, using = "altMobile") 
	@CacheLookup
	WebElement alt_mobile;

	@FindBy(how = How.NAME, using = "language") 
	@CacheLookup
	List<WebElement> language;
	/*
	@FindBy(how = How.NAME, using = "lang2") 
	@CacheLookup
	WebElement lang2;
	
	@FindBy(how = How.NAME, using = "lang3") 
	@CacheLookup
	WebElement lang3;*/
	
	/*@FindBy(how = How.NAME, using = "gender1") 
	@CacheLookup
	WebElement gender1;
	
	@FindBy(how = How.NAME, using = "gender2") 
	@CacheLookup
	WebElement gender2;*/
	
	public List<WebElement> getLang() {
		return language;
	}

	public void setLang(List<Integer> language) {
		Iterator<Integer> it = language.iterator();
		while(it.hasNext()) {
			int a= it.next();
			if(a==1) 
				this.language.get(0).click();
			if(a==2)
				this.language.get(1).click();
		    if(a==3) {
			this.language.get(2).click();
		    }else {}
		   	}
	}


	@FindBy(how = How.NAME, using = "gender") 
	@CacheLookup
	List<WebElement> gender;
	
	
	/*public WebElement getGender1() {
		return gender1;
	}

	public void setGender1() {
		gender1.click();
	}

	public WebElement getGender2() {
		return gender2;
	}

	public void setGender2() {
		gender2.click();
	}*/

	

	public List<WebElement> getGender() {
		return gender;
	}

	public void setGender(String gen) {
		if(gen.equalsIgnoreCase("male"))
		{
			this.gender.get(0).click();
		}
		else if(gen.equalsIgnoreCase("female"))
		{
			this.gender.get(1).click();
		}
		else
		{
			
		}
	}

	

	public WebElement getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getAlt_mobile() {
		return alt_mobile;
	}

	public void setAlt_mobile(String alt_mobile) {
		this.alt_mobile.sendKeys(alt_mobile);
	}
	
	public FormPageFactory() {
		// TODO Auto-generated constructor stub
	}

		
	WebDriver wd;
	public FormPageFactory(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}
	@FindBy(xpath="/html/body/center/form/input[17]")
	@CacheLookup
	WebElement button;

	
	public WebElement getButton() {
		return button;
	}

	public void setButton() {
		button.click();
	}

	public FormPageFactory(WebElement userName, WebElement city, WebElement password, WebElement mobile,
			WebElement email, WebElement alt_mobile, WebElement lang1, WebElement lang2, WebElement lang3, WebDriver wd,
			WebElement button) {
		super();
		this.userName = userName;
		this.city = city;
		this.password = password;
		this.mobile = mobile;
		this.email = email;
		this.alt_mobile = alt_mobile;
		
		this.wd = wd;
		this.button = button;
	}

	@Override
	public String toString() {
		return "FormPageFactory [userName=" + userName + ", city=" + city + ", password=" + password + ", mobile="
				+ mobile + ", email=" + email + ", alt_mobile=" + alt_mobile + ", language=" + language + ", gender="
				+ gender + ", wd=" + wd + ", button=" + button + "]";
	}

	
	
	
}
