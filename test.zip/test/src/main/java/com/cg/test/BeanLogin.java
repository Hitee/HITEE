package com.cg.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BeanLogin {


	WebDriver driver;
	// Elements
	@FindBy(name = "userid")
	@CacheLookup
	WebElement userid;


	@FindBy(name = "password")
	@CacheLookup
	WebElement password;

	@FindBy(name = "sum")
	@CacheLookup
	WebElement sum;

	public WebDriver getDriver() {
		return driver;
	}


	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}


	public WebElement getUserid() {
		return userid;
	}


	public void setUserid(String userid) {
		this.userid.sendKeys(userid);
	}


	public WebElement getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getSum() {
		return sum;
	}

	public void setSum(String sum) {
		this.sum.sendKeys(sum);
	}
	public void setButton() {
		sum.click();
	}

	public BeanLogin(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
}
