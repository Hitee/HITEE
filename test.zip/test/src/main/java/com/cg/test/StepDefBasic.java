package com.cg.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefBasic {
	private WebDriver driver;
	private BeanBasic obj;

	@Before
	public void beforeConfirm() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Hitee Sachdeva\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
	}



	@Given("^User wants to enter company name$")
	public void user_wants_to_enter_company_name() throws Throwable {

		obj = new BeanBasic(driver);
		driver.get("file:///D:/sts%20workspace/test/src/BasicForm.html");

	}

	@When("^user enter null company name$")
	public void user_enter_null_company_name() throws Throwable {

		//obj.setMobile("");
		//obj.setEmail("sara@gmail.com");
		//obj.setNumber("9564215217");
		//List<Integer> l1= new ArrayList<>();
		//l1.add(1);
		//l1.add(2);
		//obj.setLanguage(l1);
		//obj.setGender("male");
		//obj.setPassword("abc");
		//obj.setCity("Chennai");
		obj.setUserName("Saransh"); 
		//obj.setCompanyName("Capgemini");



		obj.setCompanyName("");
		obj.setButton();
	}

	@Then("^print error msg for company name$")
	public void print_error_msg_for_company_name() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "please fill companyName..");

	}

	@Given("^User wants to enter name$")
	public void user_wants_to_enter_name() throws Throwable {

		obj = new BeanBasic(driver);
		driver.get("file:///D:/sts%20workspace/test/src/BasicForm.html");


	}

	@When("^user enter null username$")
	public void user_enter_null_username() throws Throwable {
		obj.setUserName(""); 
		obj.setCompanyName("Capgemini");
		obj.setButton();
	}

	@Then("^print error msg for name$")
	public void print_error_msg_for_name() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "please fill username..");

	}

	@Given("^User wants to enter cty$")
	public void user_wants_to_enter_cty() throws Throwable {
		obj = new BeanBasic(driver);
		driver.get("file:///D:/sts%20workspace/test/src/BasicForm.html");

	}

	@When("^user enter null cty$")
	public void user_enter_null_cty() throws Throwable {

		obj.setUserName("Saransh"); 
		obj.setCompanyName("Capgemini");
		obj.setCity("");
		obj.setButton();
	}

	@Then("^print error msg for cty$")
	public void print_error_msg_for_cty() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "please fill city..");

	}

	@Given("^User wants to enter password$")
	public void user_wants_to_enter_password() throws Throwable {
		obj = new BeanBasic(driver);
		driver.get("file:///D:/sts%20workspace/test/src/BasicForm.html");

	}

	@When("^user enter null password$")
	public void user_enter_null_password() throws Throwable {

		obj.setPassword("");
		obj.setCity("Chennai");
		obj.setUserName("Saransh"); 
		obj.setCompanyName("Capgemini");
		obj.setButton();

	}

	@Then("^print error msg for password$")
	public void print_error_msg_for_password() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "please fill password..");

	}

	@Given("^User wants to enter gender$")
	public void user_wants_to_enter_gender() throws Throwable {
		obj = new BeanBasic(driver);
		driver.get("file:///D:/sts%20workspace/test/src/BasicForm.html");

	}

	@When("^user enter null gender$")
	public void user_enter_null_gender() throws Throwable {

		obj.setPassword("abc");
		obj.setCity("Chennai");
		obj.setUserName("Saransh"); 
		obj.setCompanyName("Capgemini");
		obj.setGender("");
		obj.setButton();
	}

	@Then("^print error msg for gender$")
	public void print_error_msg_for_gender() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "please fill gender..");
	}

	@Given("^User wants to enter language$")
	public void user_wants_to_enter_language() throws Throwable {
		obj = new BeanBasic(driver);
		driver.get("file:///D:/sts%20workspace/test/src/BasicForm.html");

	}

	@When("^user enter null language$")
	public void user_enter_null_language() throws Throwable {
		List<Integer> l1= new ArrayList<>();
		l1.add(1);
		l1.add(2);
		obj.setGender("male");
		obj.setPassword("abc");
		obj.setCity("Chennai");
		obj.setUserName("Saransh"); 
		obj.setCompanyName("Capgemini");
		obj.setButton();


	}

	@Then("^print error msg for language$")
	public void print_error_msg_for_language() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "please fill language..");
	}

	@Given("^User wants to enter mob number$")
	public void user_wants_to_enter_mob_number() throws Throwable {
		obj = new BeanBasic(driver);
		driver.get("file:///D:/sts%20workspace/test/src/BasicForm.html");

	}

	@When("^user enter null mob number$")
	public void user_enter_null_mob_number() throws Throwable {

		//List<Integer> l1= new ArrayList<>();
		//l1.add(1);
		/*l1.add(2);*/
		//obj.setLanguage(l1);
		obj.setUserName("Saransh"); 
		obj.setCompanyName("Capgemini");
		obj.setCity("Chennai");
		obj.setPassword("abc");
		obj.setGender("male");

		obj.setNumber("");
		obj.setButton();


	}

	@Then("^print error msg for mob number$")
	public void print_error_msg_for_mob_number() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "please fill number..");
	}

	@Given("^User wants to enter email$")
	public void user_wants_to_enter_email() throws Throwable {
		obj = new BeanBasic(driver);
		driver.get("file:///D:/sts%20workspace/test/src/BasicForm.html");

	}

	@When("^user enter null email$")
	public void user_enter_null_email() throws Throwable {
		
		obj.setCompanyName("Capgemini");
		obj.setUserName("Saransh"); 
		obj.setCity("Chennai");
		obj.setPassword("abc");
		obj.setGender("male");
		obj.setNumber("9564215217");
		obj.setEmail("");
		obj.setButton();
		//List<Integer> l1= new ArrayList<>();
		//l1.add(1);
		/*l1.add(2);*/
		//obj.setLanguage(l1);
		
		
		
		
		
		

	}

	@Then("^print error msg for email$")
	public void print_error_msg_for_email() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "please fill email..");
	}

	@Given("^User wants to enter alternate number$")
	public void user_wants_to_enter_alternate_number() throws Throwable {
		obj = new BeanBasic(driver);
		driver.get("file:///D:/sts%20workspace/test/src/BasicForm.html");


	}

	@When("^user enter null alternate number$")
	public void user_enter_null_alternate_number() throws Throwable {
		obj.setMobile("");
		obj.setEmail("sara@gmail.com");
		obj.setNumber("9564215217");
		List<Integer> l1= new ArrayList<>();
		l1.add(1);
		/*l1.add(2);*/
		obj.setLanguage(l1);
		obj.setGender("male");
		obj.setPassword("abc");
		obj.setCity("Chennai");
		obj.setUserName("Saransh"); 
		obj.setCompanyName("Capgemini");
		obj.setButton();

	}

	@Then("^print error msg for alternate number$")
	public void print_error_msg_for_alternate_number() throws Throwable {

		Assert.assertEquals(driver.switchTo().alert().getText(), "please fill mobile..");
		//asserte
	}

	/*
	@After
	public void closeDriver() {
		driver.close();
	}*/

}
