package com.cg.test;

public class LoginPOM {
	public static void main(String[] args) {
		
		
	}

}
