package com.cg.test;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class BeanBasic {

	
	WebDriver driver;
	// Elements
	@FindBy(name = "companyName")
	@CacheLookup
	WebElement companyName;

	@FindBy(name = "userName")
	@CacheLookup
	WebElement userName;
	
	
	@FindBy(name = "city")
	@CacheLookup
	WebElement city;

	@FindBy(name = "password")
	@CacheLookup
	WebElement password;
	
	@FindBy(name = "gender")
	@CacheLookup
	List<WebElement> gender;
	
	@FindBy(name = "language")
	@CacheLookup
	List<WebElement> language;
	
	@FindBy(name = "country")
	@CacheLookup
	List<WebElement> country;
	
	@FindBy(name = "number")
	@CacheLookup
	WebElement number;
	
	@FindBy(name = "email")
	@CacheLookup
	WebElement email;
	
	@FindBy(name = "mobile")
	@CacheLookup
	WebElement mobile;
	
	@FindBy(name = "sum")
	@CacheLookup
	WebElement sum;

	public BeanBasic(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	
	public WebElement getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName.sendKeys(companyName);
	}

	public WebElement getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}


	public List<WebElement> getGender() {
		return gender;
	}

	public void setGender(String gen) {
		if(gen.equalsIgnoreCase("male"))
		{
			this.gender.get(0).click();
		}
		else if(gen.equalsIgnoreCase("female"))
		{
			this.gender.get(1).click();
		}
		else
		{
			
		}
	}
	
	public List<WebElement> getLanguage() {
		return language;
	}

	public void setLanguage(List<Integer> lang) {
		Iterator<Integer> it = lang.iterator();
		while(it.hasNext())
		{
		int a = it.next();
			if(a == 1){
				this.language.get(0).click();
			} 
			if(a == 2){
				this.language.get(1).click();
				}
			if(a == 3){
				this.language.get(2).click();
				}
			else{	}
		} 
}


	
	

	public List<WebElement> getCountry() {
		return country;
	}

	public void setCountry(List<WebElement> country) {
		this.country = country;
	}

	public WebElement getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number.sendKeys(number);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}

	public WebElement getSum() {
		return sum;
	}

	public void setSum(String sum) {
		this.sum.sendKeys(sum);
	}
	public void setButton() {
		sum.click();
	}
	
	
		
	
}
