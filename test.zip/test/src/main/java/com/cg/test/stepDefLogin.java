package com.cg.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepDefLogin {

	private WebDriver driver;
	private BeanLogin obj;
	
	@Before
	public void beforeConfirm() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Hitee Sachdeva\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
	}


@Given("^user is on lgin page$")
public void user_is_on_lgin_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user enters userid and password$")
public void user_enters_userid_and_password() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^go to success page$")
public void go_to_success_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}


}
