function validate() {

	var x = document.forms["form1"]["userName"].value;
	if (x == "") {
		alert("please fill username..");
	}
	var x = document.forms["form1"]["companyName"].value;
	if (x == "") {
		alert("please fill companyName..");
	}
	var x = document.forms["form1"]["city"].value;
	if (x == "") {
		alert("please fill city..");
	}
	var x = document.forms["form1"]["password"].value;
	if (x == "") {
		alert("please fill password..");
	}
	var x = document.forms["form1"]["gender"].value;
	if (x == "") {
		alert("please fill gender..");
	}

	var x = document.forms["form1"]["number"].value;
	if (x == "") {
		alert("please fill number..");
	}
	var x = document.forms["form1"]["email"].value;
	if (x == "") {
		alert("please fill email..");
	}
	var x = document.forms["form1"]["mobile"].value;
	if (x == "") {
		alert("please fill mobile..");

	}

	var x = document.forms["form1"]["language"].value;
	if (x == "") {
		alert("please fill language..");
	}

	/*if(!(document.getElementByName('male').checked) && !(document.getElementByName('female').checked)){
		alert("Please select Gender: Male or Female");
		
	}*/	/*else if((document.getElementById('male').checked) && (document.getElementById('female').checked)){
		alert("Select only one gender button");
		return false;
	}*/
	/*if(!(documenr.getElementById('eng').checked) && !(document.getElementById('tel')) &&
					!(document.getElementById('tam').checked)){
						alert("Select atleast one Language..");
						return false;
					}*/
}
