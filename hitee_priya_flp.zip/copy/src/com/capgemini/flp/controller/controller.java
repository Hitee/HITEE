package com.capgemini.flp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.bean.Admin;
import com.capgemini.flp.bean.Order;
import com.capgemini.flp.bean.User;
import com.capgemini.flp.service.IService;

@Controller
/*@RequestMapping("/user")
*/
public class controller {
	
	@Autowired
	IService service;
/*
	@RequestMapping(value = "/details", method = RequestMethod.GET)
	public ModelAndView register( ){
		User user = new User();
		return new ModelAndView("payment" , "pay" , user);
		
	}*/
	
	/*@RequestMapping( value = "/create", method = RequestMethod.POST)
	public String create(User user , Map<String , Object> map ){
		map.put("user" , new User());
		return "redirect:/user/details" + user.getName();
		
	}
	
	@RequestMapping(value = "/details" , method = RequestMethod.GET)
	public String details(@PathVariable("name")  String name, Map<String , Object> map)
	{
		User user = userService.find("name"); 
		map.put("name", user.getName());
		map.put("card", user.getCard());
		map.put("exp_month", user.getExp_month());
		map.put("exp_year", user.getExp_year());
		map.put("cvv", user.getCvv());
		return "user/details";
	}
	*/
	@RequestMapping(value="/success", method=RequestMethod.POST)
	public ModelAndView update(@ModelAttribute(value="pay")User c){
		try{
			System.out.println("c");
			System.out.println(c);
			String status=service.create(c);
			return new ModelAndView("message","message",status);
		}catch(Exception e){
			return new ModelAndView("error","message",e.getMessage());
		}
	} 
	/*@RequestMapping(value={"/orderUpdate"})
	public ModelAndView cartDetails(@RequestParam("id") Integer productId) {
		
		Order order1= new Order();
		
		try {	
		    
			int orderId=order1.getOrderId();
			Order order=service.updateOrder(orderId,productId);
			
		return new ModelAndView("orderUpdate","order",order);
		
	
	}catch(Exception e){
		return new ModelAndView("error","message",e.getMessage());
	}
	}*/
		

	@RequestMapping(value="/details")
	void updateDetails(){
		int productid=11;
		String status=service.update(productid);
		System.out.println(status);
	}
}
