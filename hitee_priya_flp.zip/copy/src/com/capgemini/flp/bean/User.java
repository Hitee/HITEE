package com.capgemini.flp.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "paymentmode")
public class User {

	private String name;
	@Id
	private String card;
	private String exp_month;
	private String exp_year;
	private String cvv;
	public String getName() {
		return name;
	}
	public String getCard() {
		return card;
	}
	public String getExp_month() {
		return exp_month;
	}
	public String getExp_year() {
		return exp_year;
	}
	public String getCvv() {
		return cvv;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setCard(String card) {
		this.card = card;
	}
	public void setExp_month(String exp_month) {
		this.exp_month = exp_month;
	}
	public void setExp_year(String exp_year) {
		this.exp_year = exp_year;
	}
	public void setCvv(String cvv) {
		this.cvv = cvv;
	}
	public User() {
		// TODO Auto-generated constructor stub
	}
	public User(String name, String card, String exp_month, String exp_year,
			String cvv) {
		super();
		this.name = name;
		this.card = card;
		this.exp_month = exp_month;
		this.exp_year = exp_year;
		this.cvv = cvv;
	}
	
	
	
}
