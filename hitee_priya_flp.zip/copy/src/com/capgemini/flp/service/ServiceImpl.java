package com.capgemini.flp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.flp.bean.Admin;
import com.capgemini.flp.bean.Order;
import com.capgemini.flp.bean.User;
import com.capgemini.flp.dao.IDao;

@Service("userService")
//@Transactional(propagation = Propagation.SUPPORTS , rollbackFor = Exception.class)
public class ServiceImpl implements IService{

	@Autowired
	IDao dao;
	
	@Override
	public String create(User user) {
		return dao.create(user);
		
	}

	/*@Override
	public Order updateOrder(int orderId, int productId) {
		
		return dao.updateOrder(orderId, productId);
	}
*/
	@Override
	public String update(int orderid) {
		// TODO Auto-generated method stub
		return dao.update(orderid);
	}

	
}
