package com.capgemini.flp.service;

import com.capgemini.flp.bean.Admin;
import com.capgemini.flp.bean.Order;
import com.capgemini.flp.bean.User;




public interface IService {

	public String create(User user);
	//public Order updateOrder(int orderId, int productId);
	public String update(int orderid);
}
