package com.capgemini.flp.dao;

import com.capgemini.flp.bean.Admin;
import com.capgemini.flp.bean.Order;
import com.capgemini.flp.bean.User;

public interface IDao {

	public String create(User user);
	
//	public Order updateOrder(int orderId, int productId);


	public String update(int orderid);
}
