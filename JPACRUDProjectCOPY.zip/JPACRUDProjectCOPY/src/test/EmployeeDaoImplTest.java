package test;


/*(Integer pin, Double balance, String ename, String address,
			String email, String mobile, String govtid, Integer accno)
package test;*/

import static org.junit.Assert.*;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder.In;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.jpa.dao.EmployeeDaoImpl;
import com.capgemini.jpa.entity.Employee;
import com.capgemini.jpa.entity.Transaction;
import com.capgemini.jpa.exception.EmployeeException;

public class EmployeeDaoImplTest {
	EmployeeDaoImpl dao = null;
	Employee b = new Employee();
	Employee bank = new Employee();

	@Before
	public void setUp() throws Exception {
		dao= new EmployeeDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		dao = null;
	}

	@Test
	public void testCreateAccount() {
		
		b = new Employee(1,1.0,"hitee","a","a","a","a",1);
		b = new Employee(1,1.0,"harsha","a","a","a","a",1);
		
		
		
		try {
			dao.addNewEmployee(b);
		//assertNotEquals(1111, bank.getAccno());
			assertNotEquals("invalid account", 111111111, bank.getAccno());
			
		} catch (EmployeeException e) {
			
			e.printStackTrace();
		}
		try {
			dao.addNewEmployee(b);
		} catch (EmployeeException e) {
			
			e.printStackTrace();
		}
		
	}

	@Test
	public int testShowBalance() {
		try {
			//dao.showBalance(173254,3416);
			Employee d = dao.showEmployee(1, 1);
			assertNotNull(d);
			
		} catch (EmployeeException e) {
			
			e.printStackTrace();
		}
		return 0;
		
	}

	@Test
	public Double testDeposit() {
		try {
			Employee c = dao.depositEmployee(1, 1.0);
			/*assertEquals(1020.0,);*/
			assertNotNull(c);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}

	@Test
	public Double testWithdraw() {
		try {
			Double c=	dao.withdrawEmployee(1.0, 1.0, 1.0);
			/*assertEquals(1480.0, bank.getBalance());*/
			assertNotNull(c);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	@Test
	public Double testFundTransfer() {
		try {
			Double c=dao.fundTransfer(173254,193131,3416(Integer));
			assertNotNull(c);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Test
	public void testPrintTransactions() {
		 try {
			List<Transaction> printTransactions = dao.printTransactions(173254);
			assertNotNull(printTransactions);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
