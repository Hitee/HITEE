package com.capgemini.jpa.entity;



import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

@Entity
@NamedQueries({
		@NamedQuery(name="q1",query="select e from Employee e"),
		//@NamedQuery(name="q2",query="select e from Employee e where e.salary>45000.00")
		}
		)
public class Employee {
	@Id
	/*@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="empid", length=30, nullable=false)
	private Integer empid;*/
	@Column(name="accno", length=30, nullable=false)
	private Integer accno;
	@Column(name="pin", length=30, nullable=false)
	private Integer pin;
	@Column(name="balance", length=30, nullable=false)
	private Double balance;
	@Column(name="ename", length=30, nullable=false)
	private String ename;
	@Column(name="address", length=30, nullable=false)
	private String address;
	@Column(name="email", length=30, nullable=false)
	private String email;
	@Column(name="mobile", length=30, nullable=false)
	private String mobile;
	@Column(name="govtid", length=30, nullable=false)
	private String govtid;
	
	public Integer getAccno() {
		return accno;
	}

	public void setAccno(Integer accno) {
		this.accno = accno;
	}

	
	/*@Column(name="transaction", length=30, nullable=false)
	private StringBuffer transaction = null ;*/
	
	
	//@NotNull

	
	
	public Integer getPin() {
		return pin;
	}

	/*public StringBuffer getTransaction() {
		return transaction;
	}

	public void setTransaction(StringBuffer transaction) {
		this.transaction = transaction;
	}*/

	public void setPin(Integer pin) {
		this.pin = pin;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public Employee() {
		
	}

	


	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	/*public Integer getEmpid() {
		return empid;
	}

	public void setEmpid(Integer empid) {
		this.empid = empid;
	}
*/
	
	public String getAddress() {
		return address;
	}

	public String getEmail() {
		return email;
	}

	public String getMobile() {
		return mobile;
	}

	public String getGovtid() {
		return govtid;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public void setGovtid(String govtid) {
		this.govtid = govtid;
	}

	@Override
	public String toString() {
		return /*"Employee [empid=" + empid + ",*/ "pin=" + pin + ", balance="
				+ balance + ", ename=" + ename + ", address=" + address
				+ ", email=" + email + ", mobile=" + mobile + ", govtid="
				+ govtid + ", accno=" + accno + "]";
	}

	public Employee(Integer pin, Double balance, String ename, String address,
			String email, String mobile, String govtid, Integer accno) {
		super();
		this.pin = pin;
		this.balance = balance;
		this.ename = ename;
		this.address = address;
		this.email = email;
		this.mobile = mobile;
		this.govtid = govtid;
		this.accno = accno;
	}

	

	

	
	
	

	

	

	
	

	
	

	
	
	
	
	
	
}
