package com.capgemini.jpa.presentation;

import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.capgemini.jpa.entity.Employee;
import com.capgemini.jpa.exception.EmployeeException;
import com.capgemini.jpa.service.EmployeeServiceImpl;
import com.capgemini.jpa.service.IEmployeeService;

public class EmployeeTester {
	private static IEmployeeService employeeService=
			new EmployeeServiceImpl();
	private static Scanner sc =  new Scanner(System.in);

	public static void main(String[] args) throws EmployeeException {

		while(true){
			System.out.println("1. Create account ");
			System.out.println("2. Show balance ");
			System.out.println("3. Deposit");
			System.out.println("4. Withdraw");
			System.out.println("5. Fund Transfer");
			System.out.println("6. Print Transaction");
			System.out.println("7. Exit ");
			System.out.println("-------------------------------");
			System.out.println("Enter your choice: ");

			int option= sc.nextInt();
			switch(option){
			case 1:
				Employee employee1= new Employee();
				getEmployeeDetails(employee1);
				addNewEmployee(employee1);
				System.out.println(employee1);
				break;

			case 2:
				System.out.println("Enter the accno: ");
				Integer accno= sc.nextInt();
				System.out.println("Enter the pin: ");
				Integer pin= sc.nextInt();
				Employee e3 = showEmployee(accno,pin);
				System.out.println(e3);

				break;

			case 3:

				System.out.println("Enter the employee accno: ");
				Integer accno1= sc.nextInt();
				System.out.println("Enter the amount to be deposited: ");
				Double dep= sc.nextDouble();
				Employee e = depositEmployee(accno1, dep);
				System.out.println("Account number : " + e.getAccno() + " Balance : " + e.getBalance());

				break;


			case 4:

				System.out.println("Enter the accno: ");
				Integer accno2= sc.nextInt();
				System.out.println("Enter the pin: ");
				Integer pin1= sc.nextInt();
				System.out.println("Enter the amount to be withdrawn: ");
				Double withdraw= sc.nextDouble();
				Employee e1 = withdrawEmployee(accno2, withdraw, pin1);
				System.out.println("Account number : " + e1.getAccno() + " Balance : " + e1.getBalance());


				break;

			case 5:
				System.out.println("Enter your account number");
				Integer from = sc.nextInt();
				System.out.println("Enter the account number to which you want to transfer");
				Integer to = sc.nextInt();
				System.out.println("Enter amount to be transfered");
				Double transfer = sc.nextDouble();
				Employee e2 = fundTransfer(from, to, transfer);
				break;


			case 6:
				System.out.println("Enter account number:");
				Integer accno3 = sc.nextInt();
				printTransaction(accno3);
				
				break;
				
			case 7:
				System.exit(0);
			default:
				System.out.println("Enter Proper option: (1-7)");

			}
		}

	}



	private static Employee depositEmployee(Integer accno, Double dep) {
		// TODO Auto-generated method stub
		try {
			return employeeService.depositEmployee(accno, dep);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
	
	
	
	private static Employee withdrawEmployee(Integer accno, Double withdraw, Integer pin) {
		// TODO Auto-generated method stub
		try {
			return employeeService.withdrawEmployee(accno, withdraw, pin);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	

	private static Employee fundTransfer(Integer from, Integer to,  Double transfer) {
		// TODO Auto-generated method stub
		//employeeService.fundTransfer(from, to, transfer);
		try {
			return employeeService.fundTransfer(from, to, transfer);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	private static void printTransaction(Integer accno) {
		// TODO Auto-generated method stub
		//employeeService.fundTransfer(from, to, transfer);
		try {
			employeeService.printTransactions(accno);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	private static Employee showEmployee(Integer accno, Integer pin) {
		// TODO Auto-generated method stub
		try {
			return employeeService.showEmployee(accno,pin);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	private static void getEmployeeDetails(Employee employee1) {

		System.out.println("Enter employee name:");
		employee1.setEname(sc.next());
		System.out.println("Enter balance");
		employee1.setBalance(sc.nextDouble());
		
		Random rnd = new Random();
		Integer accno = 100 + rnd.nextInt(900);
		System.out.println("Your account number is: " + accno);
		employee1.setAccno(accno);
		System.out.println(employee1.getAccno());
		
		Random rnd1 = new Random();
		Integer pin = 100 + rnd.nextInt(900);
		System.out.println("Your pin number is: " + pin);
		employee1.setPin(pin);
		
		/*System.out.println("Enter account number: ");
		employee1.setAccno(sc.nextInt());
		System.out.println("Enter pin: ");
		employee1.setPin(sc.nextInt());*/
		System.out.println("Enter address");
		employee1.setAddress(sc.next());
		System.out.println("Enter email");
		employee1.setEmail(sc.next());
		System.out.println("Enter mobile");
		employee1.setMobile(sc.next());
		System.out.println("Enter government id number");
		employee1.setGovtid(sc.next());
		
		//StringBuffer sb = null;
		//sb.append("....");
		//employee1.setTransaction(sb);

	}

	private static void addNewEmployee(Employee employee) {
		try {
			employeeService.addNewEmployee(employee);
		} catch (EmployeeException e) {			
			e.printStackTrace();
		}

	}

}
