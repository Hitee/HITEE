package com.capgemini.jpa.service;

import java.util.List;

import com.capgemini.jpa.dao.EmployeeDaoImpl;
import com.capgemini.jpa.dao.IEmployeeDAO;
import com.capgemini.jpa.entity.Employee;
import com.capgemini.jpa.entity.Transaction;
import com.capgemini.jpa.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {
	private IEmployeeDAO employeeDAO=new EmployeeDaoImpl();

	@Override
	public Integer addNewEmployee(Employee employee) throws EmployeeException {
		return employeeDAO.addNewEmployee(employee);
		
	}

	@Override
	public Employee showEmployee(Integer accno, Integer pin) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDAO.showEmployee(accno, pin);
	}



	@Override
	public Employee depositEmployee(Integer accno, Double dep) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDAO.depositEmployee(accno, dep);
	}

	@Override
	public Employee withdrawEmployee(Integer accno, Double withdraw, Integer pin)
			throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDAO.withdrawEmployee(accno, withdraw, pin);

	}

	@Override
	public Employee fundTransfer(Integer from, Integer to, Double transfer) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDAO.fundTransfer(from, to, transfer);
	}

	

	@Override
	public List<Transaction> printTransactions(int accountNumber)
			throws EmployeeException {
		return employeeDAO.printTransactions(accountNumber);
	}

}
