package com.capgemini.jpa.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.jpa.dao.EmployeeDaoImpl;
import com.capgemini.jpa.dao.IEmployeeDAO;
import com.capgemini.jpa.entity.Employee;
import com.capgemini.jpa.entity.Transaction;
import com.capgemini.jpa.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {
	private IEmployeeDAO employeeDAO=new EmployeeDaoImpl();

	@Override
	public Integer addNewEmployee(Employee employee) throws EmployeeException {
		return employeeDAO.addNewEmployee(employee);
		
	}

	@Override
	public Employee showEmployee(Integer accno, Integer pin) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDAO.showEmployee(accno, pin);
	}



	@Override
	public Employee depositEmployee(Integer accno, Double dep) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDAO.depositEmployee(accno, dep);
	}

	@Override
	public Employee withdrawEmployee(Integer accno, Double withdraw, Integer pin)
			throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDAO.withdrawEmployee(accno, withdraw, pin);

	}

	@Override
	public Employee fundTransfer(Integer from, Integer to, Double transfer) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDAO.fundTransfer(from, to, transfer);
	}

	

	@Override
	public List<Transaction> printTransactions(int accountNumber)
			throws EmployeeException {
		return employeeDAO.printTransactions(accountNumber);
	}

	
	

	public boolean validateName(String name) {
		boolean a;
		String regx = "[a-zA-Z]{2,20}+";
	    Pattern pattern = Pattern.compile(regx,Pattern.CASE_INSENSITIVE);
	    Matcher matcher = pattern.matcher(name);
	    a =  matcher.find();
	    if(a==false)
	    {
	    	System.out.println("wrong name");
	    	return false;
	    }
	    else 
	    	return true;
	}
	
	
	public boolean isValidEmailAddress(String email) {
        String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
        java.util.regex.Matcher m = p.matcher(email);
        return m.matches();
 }
	
	public boolean validateNumber(String mobile)
	{
		
		if (mobile.matches("[0-9]{10}")) {
			 return true; 
			
		}
		else System.out.println("invalid mobile number");
		return false;
	}
	
	public boolean govtid(String id)
	{
		
		if (id.matches("[0-9]{5}")) {
			 return true; 
			
		}
		else System.out.println("invalid id number");
		return false;
	}
	
	
	
	
	
	
	
}
