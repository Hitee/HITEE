package com.capgemini.jpa.dao;

import java.util.List;

import com.capgemini.jpa.entity.Employee;
import com.capgemini.jpa.entity.Transaction;
import com.capgemini.jpa.exception.EmployeeException;

public interface IEmployeeDAO {
	public abstract Integer addNewEmployee(Employee employee) throws EmployeeException;
	public abstract Employee showEmployee(Integer accno, Integer pin) throws EmployeeException;
	public abstract Employee depositEmployee(Integer accno, Double dep) throws EmployeeException;
	public abstract Employee withdrawEmployee(Integer accno, Double withdraw , Integer pin) throws EmployeeException;
	public abstract Employee fundTransfer(Integer from, Integer to, Double transfer) throws EmployeeException;
	 public List<Transaction> printTransactions(int accountNumber) throws EmployeeException;//
	
}
