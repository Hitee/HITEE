package com.capgemini.jpa.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.capgemini.jpa.entity.Employee;
import com.capgemini.jpa.entity.Transaction;
import com.capgemini.jpa.exception.EmployeeException;
import com.capgemini.jpa.utility.JPAUtil;

public class EmployeeDaoImpl implements IEmployeeDAO {
	private EntityManager entityManager= null;

	@Override
	public Integer addNewEmployee(Employee b) throws EmployeeException {

		try{
			entityManager=JPAUtil.getEntityManager();
			
			entityManager.getTransaction().begin();
			
			
			Transaction trans = new Transaction();
			trans.setBankAccount(b);
			trans.setTransactionAmount(b.getBalance());
			trans.setTransactionType("Deposited");
			entityManager.persist(trans);
			
			
			entityManager.persist(b); //add in table
			entityManager.getTransaction().commit();	
			
		}catch(PersistenceException e) {
			e.printStackTrace();
			
			throw new EmployeeException(e.getMessage());
		}finally {
			entityManager.close();
		}
		return 0;
		
		
		
	}

	@Override
	public Employee showEmployee(Integer accno, Integer pin) throws EmployeeException {
		Employee employee=null;
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			employee = entityManager.find(Employee.class, accno);
			//Employee employee= entityManager.find(Employee.class, accno);
			System.out.println("employee :" + employee);
			if(employee.getAccno() == accno && employee.getPin() == pin)
			{
				//System.out.println("Account Balance is: " + employee.getBalance());
			}
			/*else
				System.out.println("Invalid Credentials");*/
			

			
			entityManager.getTransaction().commit();			
		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new EmployeeException(e.getMessage());
		}finally {
			entityManager.close();
		}
		return employee;
		
		

	}







	@Override
	public Employee depositEmployee(Integer accno, Double dep) throws EmployeeException {
		// TODO Auto-generated method stub
		Employee employee= null;
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			employee= entityManager.find(Employee.class, accno);
			System.out.println(accno + "---" + "----" + employee);
			//Employee b = entityManager.find(Employee.class,accno);
			Double present = employee.getBalance();
			present += dep; 
			employee.setBalance(present);
			entityManager.merge(employee);
			Transaction trans = new Transaction();
			trans.setTransactionAmount(dep);
			trans.setTransactionType("Deposited");
			trans.setBankAccount(employee);
			entityManager.persist(trans);
	
			entityManager.getTransaction().commit();	

			//System.out.println("Account Balance is: " + employee.getBalance());



		}catch(PersistenceException e) {
			e.printStackTrace();
			
			throw new EmployeeException(e.getMessage());
		}finally {
			entityManager.close();
		}
		return employee;
		

	}

	@Override
	public Employee withdrawEmployee(Integer accno, Double withdraw ,Integer pin)
			throws EmployeeException {
		Employee employee = null;
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			employee= entityManager.find(Employee.class, accno);
			//System.out.println(accno);
			//System.out.println(employee.getAccno());
			//if(employee.getAccno() == accno && employee.getPin() == pin)
			//{
				Double present = employee.getBalance();
			present -= withdraw; 
			employee.setBalance(present);
			
			Transaction trans = new Transaction();
			trans.setTransactionAmount(withdraw);
			trans.setTransactionType("Withdrawn");
			trans.setBankAccount(employee);
			entityManager.persist(trans);
			
			entityManager.merge(employee);
			entityManager.getTransaction().commit();	

			//System.out.println("Account Balance is: " + employee.getBalance());

			//}
			//else
			//System.out.println("Invalid Credentials");
			
			


		}catch(PersistenceException e) {
			e.printStackTrace();
			
			throw new EmployeeException(e.getMessage());
		}finally {
			entityManager.close();
		}
		return employee;
		
		

	}

	@Override
	public Employee fundTransfer(Integer from, Integer to, Double transfer) throws EmployeeException {
		Employee employee_from = null;
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			
			employee_from = entityManager.find(Employee.class, from);
			Employee employee_to = entityManager.find(Employee.class, to);
			
			
			Double present_from = employee_from.getBalance();
			Double present_to = employee_to.getBalance();
			
			present_from -= transfer;
			present_to += transfer;
			employee_from.setBalance(present_from);
			employee_to.setBalance(present_to);
			
			//FROM
			Transaction trans_from = new Transaction();
			trans_from.setTransactionAmount(transfer);
			trans_from.setTransactionType("Fund Transfer(Sent)");
			trans_from.setBankAccount(employee_from);
			entityManager.persist(trans_from);
			
			//TO
			Transaction trans_to = new Transaction();
			trans_to.setTransactionAmount(transfer);
			trans_to.setTransactionType("Fund Transfer(Recieved)");
			trans_to.setBankAccount(employee_to);
			entityManager.persist(trans_to);
			
			
			entityManager.merge(employee_from);
			entityManager.merge(employee_to);
			
			entityManager.getTransaction().commit();	

			System.out.println("Account Balance(FROM) is: " + employee_from.getBalance());
			System.out.println("Account Balance(TO) is: " + employee_to.getBalance());



		}catch(PersistenceException e) {
			e.printStackTrace();
			
			throw new EmployeeException(e.getMessage());
		}finally {
			entityManager.close();
		}
		return employee_from;
		
		
	}

	

	@Override
	public List<Transaction> printTransactions(int accountNumber)
			throws EmployeeException {
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
	    Query query=entityManager.createNativeQuery("select*from bank_tranaction where account_Number=?",Transaction.class);
		query.setParameter(1,accountNumber);
		
	    List<Transaction> transList = query.getResultList();
	    System.out.println(transList);
	    return transList;
		}catch(PersistenceException e) {
			e.printStackTrace();
			

			throw new EmployeeException(e.getMessage());
		}finally {
			entityManager.close();
			
		}
	}

}
