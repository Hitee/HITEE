package com.cg.selen;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * Hello world!
 *
 */
public class App 
{
	public static void main( String[] args )
	{


		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.com");

		WebElement element = driver.findElement(By.name("q"));
		//WebElement element = driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div/div[1]/div/div[1]/input"));
		//WebElement element = driver.findElement(By.cssSelector("#tsf > div:nth-child(2) > div > div.RNNXgb > div > div.a4bIc > input"));
		//WebElement element = driver.findElement(By.className("gLFyf"));
		//WebElement element = driver.findElement(By.
		
		element.sendKeys("Cheese!");
		//WebElement button = driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div/div[3]/center/input[1]"));
		//WebElement button = driver.findElement(By.className("btnK"));
		WebElement button = driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div/div[3]/center/input[1]"));
		button.click();
		//button.
		//System.out.println("Page title is: " + driver.getTitle());
		
		//class path "gLFyf gsfi"
		/*System.out.println(driver.getPageSource()); 
		
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.navigate().forward(); */

		//driver.navigate().refresh();
		//driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

		//driver.quit();
		// driver.close();
		// System.out.println(driver.getPageSource()); 

		// driver.navigate().to("https://www.amazon.com");


	}
}
