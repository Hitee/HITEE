package com.cg.selen;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class myhtml {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/hisachde/Desktop/myhtml.html");

		//radio
		WebElement element = driver.findElement(By.name("gender2"));
		element.click();
		
		//checkbox
		element = driver.findElement(By.name("vehicle2"));
		element.click();
		
		//dropdown
		Select car = new Select(driver.findElement(By.name("cars")));
		car.selectByVisibleText("Audi");
		
	}

}
