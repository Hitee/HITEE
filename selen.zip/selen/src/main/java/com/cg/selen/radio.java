package com.cg.selen;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class radio {
	public static void main( String[] args )
	{
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		//driver.get("http://demo.guru99.com/test/radio.html");
		//radio 
		//WebElement element = driver.findElement(By.id("vfb-7-3"));
		//element.click();
		
		//checkbox
		//WebElement element = driver.findElement(By.id("vfb-6-1"));
		//element.click();
		
		driver.get("http://demo.guru99.com/test/newtours/register.php");
		Select drpCountry = new Select(driver.findElement(By.name("country")));
		drpCountry.selectByVisibleText("INDIA");
		//WebElement element = driver.findElement(By.id("country"));
		//element.click();

	}
}