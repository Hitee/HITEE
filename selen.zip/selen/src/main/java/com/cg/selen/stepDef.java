package com.cg.selen;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class stepDef {


	@Given("^user on myhtml_page and enter mobile number$")
	public void user_on_myhtml_page_and_enter_mobile_number() throws Throwable {

	}



	@Then("^check for true <mob number>$")
	public void check_for_true_mob_number(DataTable arg1) throws Throwable {

		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/hisachde/Desktop/myhtml.html");

		WebElement element = driver.findElement(By.name("mobile number"));
		List<String> list = arg1.asList(String.class);

		List<String> l1 = arg1.asList(String.class);
		l1.stream().forEach(System.out::println);
		long c = l1.stream().count();

		for(int i=0 ; i<c; i++)
		{
			String a = list.get(i);
			System.out.println("mobile number - " + a);

			element.sendKeys(a);
			//element.clear();

			assertTrue(a.matches("[0-9]{10}"));

		}
	}





	@Given("^User is on myhtml_page and enter mobile number$")
	public void user_is_on_myhtml_page_and_enter_mobile_number() throws Throwable {

	}



	@Then("^check for false <mobile number>$")
	public void check_for_false_mobile_number(DataTable arg1) throws Throwable {

		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/hisachde/Desktop/myhtml.html");

		WebElement element = driver.findElement(By.name("mobile number"));
		List<String> list = arg1.asList(String.class);

		List<String> l1 = arg1.asList(String.class);
		l1.stream().forEach(System.out::println);
		long c = l1.stream().count();

		for(int i=0 ; i<c; i++)
		{
			String a = list.get(i);
			System.out.println("mobile number - " + a);

			element.sendKeys(a);
			//element.clear();
			assertFalse(a.matches("[0-9]{10}"));
			//assertTrue(a.matches("[0-9]{10}"));

		}
	}


	@Given("^myhtml_page is open and enter f_name$")
	public void myhtml_page_is_open_and_enter_f_name() throws Throwable {

	}

	@Then("^check for true <f_name>$")
	public void check_for_true_f_name(DataTable arg1) throws Throwable {

		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/hisachde/Desktop/myhtml.html");

		WebElement element = driver.findElement(By.name("firstname"));
		List<String> list = arg1.asList(String.class);

		List<String> l1 = arg1.asList(String.class);
		l1.stream().forEach(System.out::println);
		long c = l1.stream().count();

		for(int i=0 ; i<c; i++)
		{
			String a = list.get(i);
			System.out.println("first name - " + a);

			element.sendKeys(a);
			//element.clear();
			assertTrue(a.matches("[A-Z][a-z]+"));
			//assertTrue(a.matches("[0-9]{10}"));

		}


	}

	@Given("^myhtml_page is opened and enter f_name$")
	public void myhtml_page_is_opened_and_enter_f_name() throws Throwable {

	}

	@Then("^check for false <f_name>$")
	public void check_for_false_f_name(DataTable arg1) throws Throwable {

		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/hisachde/Desktop/myhtml.html");

		WebElement element = driver.findElement(By.name("firstname"));
		List<String> list = arg1.asList(String.class);

		List<String> l1 = arg1.asList(String.class);
		l1.stream().forEach(System.out::println);
		long c = l1.stream().count();

		for(int i=0 ; i<c; i++)
		{
			String a = list.get(i);
			System.out.println("first name - " + a);

			element.sendKeys(a);
			//element.clear();
			assertFalse(a.matches("[A-Z][a-z]+"));
			//assertTrue(a.matches("[0-9]{10}"));

		}


	}



	@Given("^myhtml_page is open and enter l_name$")
	public void myhtml_page_is_open_and_enter_l_name() throws Throwable {

	}

	@Then("^checkss for true <l_name>$")
	public void checkss_for_true_l_name(DataTable arg1) throws Throwable {

		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/hisachde/Desktop/myhtml.html");

		WebElement element = driver.findElement(By.name("lastname"));
		List<String> list = arg1.asList(String.class);

		List<String> l1 = arg1.asList(String.class);
		l1.stream().forEach(System.out::println);
		long c = l1.stream().count();

		for(int i=0 ; i<c; i++)
		{
			String a = list.get(i);
			System.out.println("last name - " + a);

			element.sendKeys(a);
			//element.clear();
			assertTrue(a.matches("[A-Z][a-z]+"));
			//assertTrue(a.matches("[0-9]{10}"));
		}
	}

	@Given("^myhtml_page is opened and enter l_name$")
	public void myhtml_page_is_opened_and_enter_l_name() throws Throwable {

	}

	@Then("^checks for false <l_name>$")
	public void checks_for_false_l_name(DataTable arg1) throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/hisachde/Desktop/myhtml.html");

		WebElement element = driver.findElement(By.name("lastname"));
		List<String> list = arg1.asList(String.class);

		List<String> l1 = arg1.asList(String.class);
		l1.stream().forEach(System.out::println);
		long c = l1.stream().count();

		for(int i=0 ; i<c; i++)
		{
			String a = list.get(i);
			System.out.println("last name - " + a);

			element.sendKeys(a);
			//element.clear();
			assertFalse(a.matches("[A-Z][a-z]+"));
			//assertTrue(a.matches("[0-9]{10}"));

		}
	}



	@Given("^html page is open$")
	public void html_page_is_open() throws Throwable {
		
	}

	@Then("^check for true <balance>$")
	public void check_for_true_balance(DataTable arg1) throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/hisachde/Desktop/myhtml.html");

		WebElement element = driver.findElement(By.name("balance"));
		List<String> list = arg1.asList(String.class);

		List<String> l1 = arg1.asList(String.class);
		l1.stream().forEach(System.out::println);
		long c = l1.stream().count();

		for(int i=0 ; i<c; i++)
		{
			String a = list.get(i);
			System.out.println("balance - " + a);

			element.sendKeys(a);
			//element.clear();
			//assertFalse(a.matches("[A-Z][a-z]+"));
			assertTrue(a.matches("^(([0-9]*[1-9][0-9]*([.][0-9]+)?)|([0]+[.][0-9]*[1-9][0-9]*))$"));

		}
	}

	@Given("^html page opens$")
	public void html_page_opens() throws Throwable {
		
	}

	@Then("^check for false <balance>$")
	public void check_for_false_balance(DataTable arg1) throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/hisachde/Desktop/myhtml.html");

		WebElement element = driver.findElement(By.name("balance"));
		List<String> list = arg1.asList(String.class);

		List<String> l1 = arg1.asList(String.class);
		l1.stream().forEach(System.out::println);
		long c = l1.stream().count();

		for(int i=0 ; i<c; i++)
		{
			String a = list.get(i);
			System.out.println("balance - " + a);

			element.sendKeys(a);
			//element.clear();
			//assertFalse(a.matches("^0*[1-9]\\d*$"));
			assertFalse(a.matches("^(([0-9]*[1-9][0-9]*([.][0-9]+)?)|([0]+[.][0-9]*[1-9][0-9]*))$"));
			//assertTrue(a.matches("[0-9]{10}"));

		}
	}



}


